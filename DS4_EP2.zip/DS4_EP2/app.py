#Nombre: Victor Imanol Castillo Morales     Fecha: 07 de mayo de 2021

from flask import Flask, render_template, request, session
import secrets

app = Flask(__name__)
app.debug=True

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
app.run(debug=True)

@app.route('/', methods=['GET','POST'])
def index():
    resultado=None
    if request.method == 'POST':
        tam = request.form['tam']
        velocidad = request.form['velocidad']
        duracion = request.form['duracion']
        valor = request.form['calcular']
        if(valor=="Calcular velocidad"):
            if (tam == '' or duracion == ''):
                return render_template("index.html", resultado='Llena los campos correspondientes a la operacion.')
            velocidad = (int(tam)*8)/int(duracion)
            total = str(velocidad)+' Mb/s'
        if (valor =="Calcular duracion"):
            if (tam == '' or velocidad == ''):
                return render_template("index.html", resultado='Llena los campos correspondientes a la operacion.')
            duracion = (int(tam)*8)/int(velocidad)
            total = str(duracion)+' s'
        if (valor =="Calcular tamaño"):
            if (velocidad == '' or duracion == ''):
                return render_template("index.html", resultado='Llena los campos correspondientes a la operacion.')
            tam = (int(velocidad)*int(duracion))/8
            total = str(tam)+' MB'
        
        return render_template("index.html", resultado=total)
    else:
        return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0